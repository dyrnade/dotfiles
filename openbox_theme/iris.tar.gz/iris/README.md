iris
====

A simple, flat and bold GTK theme.

This repo was made to host the dark version of the Iris theme. The repository for Iris Light is at http://github.com/xyl0n/iris-light
